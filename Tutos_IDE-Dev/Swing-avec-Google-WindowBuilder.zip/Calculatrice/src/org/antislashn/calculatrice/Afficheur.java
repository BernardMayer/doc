package org.antislashn.calculatrice;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.SwingConstants;

public class Afficheur extends JPanel {
	private JTextField afficheur;

	/**
	 * Create the panel.
	 */
	public Afficheur() {
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setFont(new Font("Tahoma", Font.PLAIN, 11));
		setLayout(new BorderLayout(0, 0));
		
		afficheur = new JTextField();
		afficheur.setHorizontalAlignment(SwingConstants.RIGHT);
		afficheur.setEditable(false);
		afficheur.setFont(new Font("Tahoma", Font.PLAIN, 30));
		afficheur.setMinimumSize(new Dimension(10, 40));
		afficheur.setForeground(new Color(0, 0, 255));
		afficheur.setBackground(new Color(211, 211, 211));
		add(afficheur, BorderLayout.CENTER);
		afficheur.setColumns(10);

	}
	
	public void setAffichage(String message){
		afficheur.setText(message);
	}
}

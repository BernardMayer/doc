package org.antislashn.calculatrice;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatriceLogic implements ActionListener{
private String affichage = "";
private String memoire = "";
private Operations operation = null;
private boolean effacerAffichage = false;;
private IHMCalculatrice ihm;
	
	private enum Operations { MUL, DIV, PLUS, MOINS };
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String cde = e.getActionCommand();
		if(cde.equalsIgnoreCase("bsp")){
			if(affichage.length()>0)
				affichage = affichage.substring(0,affichage.length()-1);
			majAffichage("");
		}
		else if(cde.equalsIgnoreCase("ce")){
			affichage="";
			majAffichage("");
		}
		else if(cde.equalsIgnoreCase("clr")){
			affichage = "";
			memoire = "";
			operation = null;
			effacerAffichage = false;
			majAffichage("");
		}
		else if(cde.equalsIgnoreCase("+/-"))
			inverserSigne();
		else if(cde.equalsIgnoreCase("+"))
		{
			effectuerOperation();
			memoriser(Operations.PLUS);
		}
		else if(cde.equalsIgnoreCase("/"))
		{
			effectuerOperation();
			memoriser(Operations.DIV);
		}
		else if(cde.equalsIgnoreCase("x"))
		{
			effectuerOperation();
			memoriser(Operations.MUL);
		}
		else if(cde.equalsIgnoreCase("-"))
		{
			effectuerOperation();
			memoriser(Operations.MOINS);
		}
		else if(cde.equalsIgnoreCase("="))
		{
			effectuerOperation();
			affichage = memoire;
			memoire="";
			operation=null;
			majAffichage("");
			effacerAffichage =  true;
		}
		else if(cde.equalsIgnoreCase("point"))
			majAffichage(".");
		else
			majAffichage(cde);
	}

	
	public void setIhm(IHMCalculatrice ihm) {
		this.ihm = ihm;
	}
	
	private void majAffichage(String chiffre){
		if(effacerAffichage){
			effacerAffichage = false;
			affichage = chiffre;
		}
		else
			this.affichage += chiffre;
		this.ihm.setAffichage(affichage);
	}
	
	private void effectuerOperation(){
		if(operation == null)
			return;
		double operande1 = Double.parseDouble(memoire);
		double operande2 = Double.parseDouble(affichage);
		double resultat = 0;
		switch(operation){
		case MUL:
			resultat = operande1 * operande2;
			break;
		case DIV:
			resultat = operande1 / operande2;
			break;
		case PLUS:
			resultat = operande1 + operande2;
			break;
		case MOINS:
			resultat = operande1 - operande2;
			break;
		}
		memoire = Double.toString(resultat);
		affichage = memoire;
		majAffichage("");
	}

	private void inverserSigne() {
		effacerAffichage = false;
		if(affichage.length()==0)
			return;
		if(affichage.charAt(0) == '-')
			affichage = affichage.substring(1);
		else
			affichage = "-"+affichage;
		majAffichage("");
		
	}

	private void memoriser(Operations op){
		if(operation == null)
			memoire = affichage;
		operation = op;
		effacerAffichage = true;
	}
}

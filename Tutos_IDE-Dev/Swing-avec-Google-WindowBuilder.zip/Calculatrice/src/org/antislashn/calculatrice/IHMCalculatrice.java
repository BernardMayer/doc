package org.antislashn.calculatrice;

public interface IHMCalculatrice {
	public abstract void setAffichage(String message);
}
package org.antislashn.calculatrice;

import javax.swing.JButton;
import java.awt.Font;

public class Touche extends JButton {
	public Touche() {
		setFont(new Font("Tahoma", Font.BOLD, 14));
	}
}

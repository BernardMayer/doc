package org.antislashn.calculatrice;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Clavier extends JPanel {

	/**
	 * Create the panel.
	 */
	public Clavier() {
		setLayout(new GridLayout(5, 4, 5, 5));
		
		Touche tchBsp = new Touche();
		tchBsp.setActionCommand("bsp");
		tchBsp.setToolTipText("Supprime le dernier caract\u00E8re entr\u00E9");
		tchBsp.setText("<-");
		add(tchBsp);
		
		Touche tchCE = new Touche();
		tchCE.setActionCommand("ce");
		tchCE.setToolTipText("Efface la valeur affich\u00E9e");
		tchCE.setText("CE");
		add(tchCE);
		
		Touche tchClr = new Touche();
		tchClr.setActionCommand("clr");
		tchClr.setToolTipText("Efface tout");
		tchClr.setText("Clr");
		add(tchClr);
		
		Touche tchInverser = new Touche();
		tchInverser.setActionCommand("+/-");
		tchInverser.setText("+ / -");
		add(tchInverser);
		
		Touche tchSept = new Touche();
		tchSept.setActionCommand("7");
		tchSept.setText("7");
		add(tchSept);
		
		Touche tchHuit = new Touche();
		tchHuit.setActionCommand("8");
		tchHuit.setText("8");
		add(tchHuit);
		
		Touche tchNeuf = new Touche();
		tchNeuf.setActionCommand("9");
		tchNeuf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		tchNeuf.setText("9");
		add(tchNeuf);
		
		Touche tchDiviser = new Touche();
		tchDiviser.setActionCommand("/");
		tchDiviser.setText("/");
		add(tchDiviser);
		
		Touche tchQuatre = new Touche();
		tchQuatre.setActionCommand("4");
		tchQuatre.setText("4");
		add(tchQuatre);
		
		Touche tchCinq = new Touche();
		tchCinq.setActionCommand("5");
		tchCinq.setText("5");
		add(tchCinq);
		
		Touche tchSix = new Touche();
		tchSix.setActionCommand("6");
		tchSix.setText("6");
		add(tchSix);
		
		Touche tchMultiplier = new Touche();
		tchMultiplier.setActionCommand("x");
		tchMultiplier.setText("X");
		add(tchMultiplier);
		
		Touche tchUn = new Touche();
		tchUn.setActionCommand("1");
		tchUn.setText("1");
		add(tchUn);
		
		Touche tchDeux = new Touche();
		tchDeux.setActionCommand("2");
		tchDeux.setText("2");
		add(tchDeux);
		
		Touche tchTrois = new Touche();
		tchTrois.setActionCommand("3");
		tchTrois.setText("3");
		add(tchTrois);
		
		Touche tchSoustraire = new Touche();
		tchSoustraire.setActionCommand("-");
		tchSoustraire.setText("-");
		add(tchSoustraire);
		
		Touche tchZero = new Touche();
		tchZero.setActionCommand("0");
		tchZero.setText("0");
		add(tchZero);
		
		Touche tchVirgule = new Touche();
		tchVirgule.setActionCommand("point");
		tchVirgule.setText(",");
		add(tchVirgule);
		
		Touche tchEgal = new Touche();
		tchEgal.setActionCommand("=");
		tchEgal.setText("=");
		add(tchEgal);
		
		Touche tchAdditionner = new Touche();
		tchAdditionner.setActionCommand("+");
		tchAdditionner.setText("+");
		add(tchAdditionner);

	}
	
public void addActionListener(ActionListener listener){
	Component[] components = this.getComponents();
	for(Component c : components){
		((JButton)c).addActionListener(listener);
	}
}

}

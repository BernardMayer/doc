package org.antislashn.calculatrice;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Calculatrice extends JFrame implements IHMCalculatrice {

	private JPanel contentPane;
	private CalculatriceLogic logic;
	private Clavier clavier;
	private Afficheur afficheur;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculatrice frame = new Calculatrice();
					frame.init();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculatrice() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Calculatrice.class.getResource("/images/Calculator.png")));
		setTitle("Calculatrice");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 308, 322);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		afficheur = new Afficheur();
		afficheur.setBounds(0, 0, 292, 50);
		contentPane.add(afficheur);
		afficheur.setLayout(new BoxLayout(afficheur, BoxLayout.X_AXIS));
		
		clavier = new Clavier();
		clavier.setBounds(0, 56, 292, 230);
		contentPane.add(clavier);
	}
	
	private void init(){
		logic = new CalculatriceLogic();
		logic.setIhm(this);
		clavier.addActionListener(logic);
	}
	
	/* (non-Javadoc)
	 * @see org.antislashn.calculatrice.IHMCalculatrice#setAffichage(java.lang.String)
	 */
	@Override
	public void setAffichage(String message){
		afficheur.setAffichage(message);
	}

}
